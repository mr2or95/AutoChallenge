package Paylocity.AutoChallenge;

import java.util.List;

import org.openqa.selenium.WebElement;

import PageObjects.DashboardPage;
import junit.framework.Assert;

public class AddEmployee {
	final double grosspay = 2000.00;
	final double basesalary = 52000.00;
	final int numpaychecks = 26;
	final double employeecost = 1000.00;
	final double dependcost = 500.00;

	public void provideEmployee(DashboardPage dash, String firstname, String lastname, String nodeps) {
		
		  // provide data for our employee
		  dash.getFirstName().sendKeys(firstname);
		  dash.getLastName().sendKeys(lastname);
		  dash.getDependants().sendKeys(nodeps);
		  
		  // all of the employee data is provided so now submit the add
		  dash.getSubmitAdd().click();
		  
	}
	
	public Boolean verifyEmployee(DashboardPage dash, String firstname, String lastname, String nodeps) {
		
		// access the benefits table and return the table data
		List<WebElement> employees = dash.getEmployeeTable();
		
		// now look through the rows and find the employee just added
		for (int index = 0; index < employees.size(); index++) {
			
			if (dash.getFirstNameCol().get(index).getText().equalsIgnoreCase(firstname) &&
					dash.getLastNameCol().get(index).getText().equalsIgnoreCase(lastname)) {
					// got a match on the recently added employee
				
					// check the salary and monthly gross pay
					Assert.assertEquals("Base salary in dashboard table is not correct", basesalary, Double.parseDouble(dash.getSalaryCol().get(index).getText()));
					Assert.assertEquals("Monthly gross pay in dashboard table is not correct", grosspay, Double.parseDouble(dash.getGrossCol().get(index).getText()));
					
					// now calculate the correct benefits cost and net pay based on the number of dependents
					double benefitscost = (double) Math.round((100.0 * ((employeecost/numpaychecks) + ((dependcost/numpaychecks) * Integer.parseInt(nodeps)))))/100.0;
					String strbenefitcost = String.format("%.2f", benefitscost);
					Assert.assertEquals("Calculated Cost of benefits is not correct", strbenefitcost, dash.getBenefitCostCol().get(index).getText());
					
					double netpay = grosspay - benefitscost;
					String strnetpay = String.format("%.2f", netpay);
					Assert.assertEquals("Calculated Monthly net payment is not correct", strnetpay, dash.getNetPayCol().get(index).getText());
					
					// found a matching first and last name so return
					return(true);
			}
		}
		// there are no matching employees in the dashboard
		return(false);
		  
		  
	}
}
