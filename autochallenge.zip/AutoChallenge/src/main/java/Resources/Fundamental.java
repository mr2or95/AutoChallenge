package Resources;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Fundamental {

	// declare a global WebDriver
	WebDriver driver;
	
	public Properties loadProps() throws IOException
	{
	
		// create a properties file and utilize properties from it in our tests
		Properties prop = new Properties();
		
		FileInputStream inpfile = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\resources\\propdata.properties");
		prop.load(inpfile);
		
		return(prop);
		
	}
	
	public WebDriver defineDriver(Properties prop)
	{
		// provide a choice of browsers to use and select it as one of the defined properties 
		switch (prop.getProperty("browser_type").toString())
		{
		case "Chrome":
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\\\src\\\\main\\\\java\\\\resources\\\\chromedriver.exe");
			ChromeOptions opt = new ChromeOptions();
			if (prop.getProperty("chrome_type").toString().contains("headless"))
				// allow the test to run in background without opening browser
				opt.addArguments("headless");
			driver = new ChromeDriver(opt);			
			break;
		case "Firefox":
			System.setProperty("webdriver.gecko.driver",  System.getProperty("user.dir")+"\\\\src\\\\main\\\\java\\\\resources\\\\geckodriver.exe");
			driver = new FirefoxDriver();
			break;
		default:
			System.setProperty("webdriver.chrome.driver",  System.getProperty("user.dir")+"\\\\src\\\\main\\\\java\\\\resources\\\\chromedriver.exe");
			driver = new ChromeDriver();
			break;
		}
		
		// lets set a standard implicit wait of 5 seconds
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		return driver;
	}
	
}
