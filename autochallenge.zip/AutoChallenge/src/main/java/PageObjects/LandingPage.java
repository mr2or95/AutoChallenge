package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {
	
	WebDriver driver; 
	
	// constructor
	public LandingPage(WebDriver driver)
	{
		this.driver = driver;
	}
	
	By userid = By.cssSelector("input#Username");
	By passwd = By.cssSelector("input#Password");
	By logbut = By.xpath("//button[\"@class='btn.btn-primary'\"]");
	
	
	public WebElement getUser()
	{
		return driver.findElement(userid);
	}
	
	public WebElement getPasswd()
	{
		return driver.findElement(passwd);
	}
	
	public WebElement getLoginButton()
	{
		return driver.findElement(logbut);
	}
	
}
