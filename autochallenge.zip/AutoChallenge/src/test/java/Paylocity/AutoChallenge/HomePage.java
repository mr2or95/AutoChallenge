package Paylocity.AutoChallenge;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PageObjects.DashboardPage;
import PageObjects.LandingPage;
import Resources.Fundamental;
import junit.framework.Assert;

public class HomePage {
	Fundamental fund;
	Properties property;
	WebDriver driver;
	
  @BeforeTest
  public void prebuild() throws IOException
  {
	  	  // create an object for the Fundamental class
		  fund = new Fundamental();
		  
		  // Load up properties found in the propdata file
		  property = fund.loadProps();
  }
  
  @Test (dataProvider = "accessData")
  public void benefitsDash(String first, String last, String numdeps) throws IOException, InterruptedException {
  //public void benefitsDash() throws IOException, InterruptedException {  	  
	  // look up the browser selection from the properties file and set it up
	  driver = fund.defineDriver(property);
	  
	  driver.manage().window().maximize();
	  
	  String webaddr = property.getProperty("givenurl");
	  System.out.println(webaddr);
	  driver.get(webaddr);
	  
	  // bring in the home page objects to log into the dashboard
	  LandingPage homePage = new LandingPage(driver);
	  
	  // access the credentials from the properties file
	  String user = property.getProperty("username");
	  String passw = property.getProperty("passwd");
	  
	  // go ahead and provide credentials
	  homePage.getUser().sendKeys(user);
	  homePage.getPasswd().sendKeys(passw);
	  
	  // perform the login
	  homePage.getLoginButton().click();
	  
	  // create the dashboard page object
	  DashboardPage dash = new DashboardPage(driver);
	  
	  WebDriverWait wt = new WebDriverWait(driver,3);
	  
	  // continue when the add employee button is visible on the dashboard
	  wt.until(ExpectedConditions.visibilityOfElementLocated(dash.addemply));
	  
	  // let's add a new employee so click on the add button
	  dash.getAddBtn().click();
	  
	  // get an add employee object
	  AddEmployee addem = new AddEmployee();
	  
	  // fill in the new employee information
	  addem.provideEmployee(dash, first, last, numdeps);
	  
	  // continue only when the submit button on the add popup is gone
	  wt.until(ExpectedConditions.invisibilityOf(dash.getSubmitAdd()));
	  
	  Boolean foundmatch = addem.verifyEmployee(dash, first, last, numdeps);
	  Assert.assertTrue("The added employee was not found in the dashboard table", foundmatch);
	  
	  // Log out of benefits dashboard
	  dash.getLogOut().click();
	  
	  // close the browser
	  driver.quit();
  }
  
  @DataProvider
  public String[][] accessData()
  {
	  // create an array with data
	  String[][] employeedata = {
			  				{"Wayne","Brady","5"},
			  				{"Sherlock", "Holmes", "3"},
			  				{"Tanya", "Germain", "8"}		  				
	  						};
	  return (employeedata);
  }
}
