package PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DashboardPage {
	
		WebDriver driver; 
		
		// constructor
		public DashboardPage(WebDriver driver)
		{
			this.driver = driver;
		}
		
		public By addemply = By.cssSelector("button[id='add']");
		By fname = By.cssSelector("input[id='firstName']");
		By lname = By.cssSelector("input#lastName");
		By depends = By.cssSelector("input#dependants");
		By subadd = By.cssSelector("button#addEmployee");
		By tablerows = By.xpath("//table[\"@class='table.table-striped'\"]/tbody/tr");
		By firstnamecol = By.xpath("//table[\"@class='table.table-striped'\"]/tbody/tr/td[2]");
		By lastnamecol = By.xpath("//table[\"@class='table.table-striped'\"]/tbody/tr/td[3]");
		By salarycol = By.xpath("//table[\"@class='table.table-striped'\"]/tbody/tr/td[5]");
		By monthlygrosscol = By.xpath("//table[\"@class='table.table-striped'\"]/tbody/tr/td[6]");
		By benefitcostcol = By.xpath("//table[\"@class='table.table-striped'\"]/tbody/tr/td[7]");
		By netpaycol = By.xpath("//table[\"@class='table.table-striped'\"]/tbody/tr/td[8]");
		By logout = By.xpath("//a[text()='Log Out']");
		
		public WebElement getAddBtn()
		{
			return driver.findElement(addemply);
		}
		
		public WebElement getFirstName()
		{
			return driver.findElement(fname);
		}
		
		public WebElement getLastName()
		{
			return driver.findElement(lname);
		}
		
		public WebElement getDependants()
		{
			return driver.findElement(depends);
		}
		
		public WebElement getSubmitAdd()
		{
			return driver.findElement(subadd);
		}
		
		public List<WebElement> getEmployeeTable()
		{
			return driver.findElements(tablerows);
		}
		
		public List<WebElement> getFirstNameCol()
		{
			return driver.findElements(firstnamecol);
		}
		
		public List<WebElement> getLastNameCol()
		{
			return driver.findElements(lastnamecol);
		}
		
		public List<WebElement> getSalaryCol()
		{
			return driver.findElements(salarycol);
		}
		
		public List<WebElement> getGrossCol()
		{
			return driver.findElements(monthlygrosscol);
		}
		
		public List<WebElement> getBenefitCostCol()
		{
			return driver.findElements(benefitcostcol);
		}
		
		public List<WebElement> getNetPayCol()
		{
			return driver.findElements(netpaycol);
		}
		
		public WebElement getLogOut()
		{
			return driver.findElement(logout);
		}
}
